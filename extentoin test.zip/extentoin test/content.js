// FirstDue Dispatch Alerter - v6

const MY_UNITS = ['E24', 'Q24', 'T24', 'TWR24'];

const FIRE_KEYWORDS = [
  'working', 'apartment fire', 'struc fire', 'structure fire', 'mutual aid fire'
];

const URGENT_KEYWORDS = [
  'arrest', 'vehicle fire', 'train', 'fire investigation', 'inflicted'
];

const EMS_KEYWORDS = [
  'chest pain', 'heart', 'breathing', 'shortness of breath',
  'stroke', 'unconscious', 'unresponsive', 'seizure', 'convulsion', 'diabetic',
  'overdose', 'allergic', 'anaphylaxis', 'bleeding', 'hemorrhage', 'trauma',
  'fall', 'falls', 'mvc', 'motor vehicle', 'accident', 'injury', 'injured',
  'sick', 'ill', 'medical', 'ems', 'abdominal', 'pain', 'psych', 'mental',
  'suicide', 'suic', 'od ', 'choking', 'airway', 'baby',
  'childbirth', 'pregnancy', 'ob ', 'assault', 'stabbing', 'shooting',
  'lock out', 'lockout', 'welfare check', 'person down', 'unknown medical'
];

let myUnitsOnly = true;

function getAudioUrl(filename) {
  return chrome.runtime.getURL(filename);
}

function playSound(filename) {
  const audio = new Audio(getAudioUrl(filename));
  audio.volume = 1.0;
  audio.play().catch(err => console.warn('FirstDue Alerter: audio play failed', err));
}

function isMyUnit(unitText) {
  if (!unitText) return false;
  const units = unitText.toUpperCase().split(/[\s,]+/);
  return MY_UNITS.some(u => units.includes(u));
}

function isFireIncident(text)   { return FIRE_KEYWORDS.some(k   => (text || '').toLowerCase().includes(k)); }
function isEmsIncident(text)    { return EMS_KEYWORDS.some(k    => (text || '').toLowerCase().includes(k)); }
function isUrgentIncident(text) { return URGENT_KEYWORDS.some(k => (text || '').toLowerCase().includes(k)); }

// Always computed fresh — never cached — so toggle changes take effect immediately
function getSoundForCard(card) {
  const nameEl   = card.querySelector('.dispatch-name');
  const subEl    = card.querySelector('.subtitle');
  const dispName = nameEl ? nameEl.textContent.trim() : '';
  const unitText = subEl  ? subEl.textContent.replace(/^Units:\s*/i, '').trim() : '';
  const myUnit   = isMyUnit(unitText);

  // MY UNITS mode: only alert when my unit is on the call
  if (!myUnit && myUnitsOnly) return null;

  if (isFireIncident(dispName))   return 'fire.mp3';
  if (isEmsIncident(dispName))    return 'ems.mp3';
  if (isUrgentIncident(dispName)) return 'urgent.mp3';
  return 'tone.mp3';
}

// Sound purely by call type, ignoring unit — used by the ▶ replay button
function getSoundByType(dispName) {
  if (isFireIncident(dispName))   return 'fire.mp3';
  if (isEmsIncident(dispName))    return 'ems.mp3';
  if (isUrgentIncident(dispName)) return 'urgent.mp3';
  return 'tone.mp3';
}

// ── Simulate call ─────────────────────────────────────────────────────────────

const FAKE_FIRE_CALLS  = ['11D01 Working Structure Fire', '12B01 Vehicle Fire', '13A01 Grass/Brush Fire'];
const FAKE_EMS_CALLS   = ['26C02 Sick Person', '10C01 Chest Pain', '09B01 Cardiac Arrest'];
const FAKE_OTHER_CALLS = ['Lock Out', 'Welfare Check', 'Alarm - Commercial', 'Alarm - Residential',
                          'Investigation', 'Public Assist', 'Water Problem', 'Elevator Rescue'];

const FAKE_ADDRESSES = [
  '3400 FOSSIL CREEK BLVD, Fort Worth', '800 RIO BRAVO DR, Fort Worth',
  '5312 ROLLING MEADOWS DR, Fort Worth', '1200 EASTCHASE PKWY, Fort Worth',
  '4200 CAMP BOWIE BLVD, Fort Worth',   '9000 TEHAMA RIDGE PKWY, Fort Worth',
  '2600 W BERRY ST, Fort Worth',        '6100 SOUTHWEST BLVD, Fort Worth',
  '3100 N BEACH ST, Fort Worth',        '7800 CALMONT AVE, Fort Worth'
];

const UNIT_POOL = ['E24', 'Q24', 'T24', 'TWR24', 'E01', 'MED01A', 'E09', 'TWR01',
                   'E14', 'MED14A', 'E28', 'MED28A', 'E36', 'MED36A', 'BC6'];

function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

function simulateCall() {
  const includeMyUnit = Math.random() < 0.5;

  const roll = Math.random();
  let callName;
  if (roll < 0.50)      callName = pick(FAKE_EMS_CALLS);
  else if (roll < 0.75) callName = pick(FAKE_FIRE_CALLS);
  else                  callName = pick(FAKE_OTHER_CALLS);

  const otherPool  = UNIT_POOL.filter(u => !MY_UNITS.includes(u));
  const numExtra   = Math.floor(Math.random() * 2) + 1;
  const extraUnits = [...new Set(Array.from({length: numExtra}, () => pick(otherPool)))];
  const units      = includeMyUnit ? [pick(MY_UNITS), ...extraUnits] : extraUnits;

  const now       = new Date();
  const dateStr   = now.toLocaleString('en-US', {month:'short', day:'2-digit', year:'numeric',
                      hour:'2-digit', minute:'2-digit', second:'2-digit'});
  const shortDate = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}&nbsp;${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;

  const card = document.createElement('div');
  card.className = 'dispatch-widget';
  card.setAttribute('created-at', dateStr);
  card.innerHTML = `
    <div class="dispatch-info">
      <div class="content">
        <div class="content-left">
          <div class="title">
            <div class="dispatch-image"><img src="https://sizeup.firstduesizeup.com/img/incident.png" alt=""></div>
            <div class="dispatch-details">
              <div class="dispatch-name">${callName}</div>
              <div class="dispatch-address">${pick(FAKE_ADDRESSES)}</div>
            </div>
          </div>
          <div class="subtitle">Units: ${units.join(', ')}</div>
          <div class="dispatch-date">${shortDate}</div>
        </div>
      </div>
    </div>
    <div class="dispatch-status" style="display: none;"><div>NEW!</div></div>
  `;

  const list = document.querySelector('.dispatch-list');
  if (!list) { console.warn('FirstDue Alerter: .dispatch-list not found'); return; }
  list.insertBefore(card, list.firstChild);

  console.log(`FirstDue Alerter: SIMULATED → ${callName} | Units: ${units.join(', ')} | myUnit: ${includeMyUnit}`);
}

function createSimulateButton() {
  const btn = document.createElement('button');
  btn.id = 'fd-alerter-simulate';
  btn.textContent = '⚡ SIM CALL';
  btn.title = 'Inject a random simulated dispatch';
  btn.style.cssText = `
    position: fixed; top: 12px; right: 132px; z-index: 99999;
    color: #fff; background: #5a2d8c; border: none; border-radius: 6px;
    padding: 7px 14px; font-size: 13px; font-weight: 600; cursor: pointer;
    box-shadow: 0 2px 8px rgba(0,0,0,0.35); letter-spacing: 0.4px;
  `;
  btn.addEventListener('click', simulateCall);
  document.body.appendChild(btn);
}

// ── Toggle button ─────────────────────────────────────────────────────────────

function createToggleButton() {
  const btn = document.createElement('button');
  btn.id = 'fd-alerter-toggle';

  function update() {
    btn.textContent   = myUnitsOnly ? 'only 24s' : 'all calls';
    btn.title         = myUnitsOnly ? 'Alerting for 24s only — click for all calls'
                                    : 'Alerting all calls — click for 24s only';
    btn.style.background = myUnitsOnly ? '#1a6bbf' : '#b84a00';
  }

  btn.style.cssText = `
    position: fixed; top: 12px; right: 16px; z-index: 99999;
    color: #fff; border: none; border-radius: 6px;
    padding: 7px 14px; font-size: 13px; font-weight: 600; cursor: pointer;
    box-shadow: 0 2px 8px rgba(0,0,0,0.35); letter-spacing: 0.4px;
    transition: background 0.2s;
  `;

  btn.addEventListener('click', () => {
    myUnitsOnly = !myUnitsOnly;
    update();
    console.log(`FirstDue Alerter: mode → ${myUnitsOnly ? 'MY UNITS only' : 'ALL UNITS'}`);
  });

  update();
  document.body.appendChild(btn);
}

// ── Wire click-to-play on a card ──────────────────────────────────────────────

const clickWired = new WeakSet();

function wireCard(card, playOnWire = false) {
  if (clickWired.has(card)) return;
  clickWired.add(card);

  if (playOnWire) {
    // Evaluate sound NOW (respects current toggle state)
    const sound = getSoundForCard(card);
    if (sound) {
      const nameEl = card.querySelector('.dispatch-name');
      console.log(`FirstDue Alerter: NEW → ${nameEl ? nameEl.textContent.trim() : '?'} | playing ${sound}`);
      playSound(sound);
    }
  }

  // ▶ button — re-evaluates every click, always plays regardless of unit
  const btn = document.createElement('button');
  btn.textContent = '▶';
  btn.title = 'Replay sound';
  btn.style.cssText = `
    position: absolute; right: 8px; top: 50%; transform: translateY(-50%);
    background: rgba(0,0,0,0.55); color: #fff; border: none; border-radius: 4px;
    padding: 3px 7px; font-size: 13px; cursor: pointer; z-index: 9999;
    line-height: 1.4; opacity: 0; transition: opacity 0.15s;
  `;

  const infoEl = card.querySelector('.dispatch-info');
  if (infoEl) {
    infoEl.style.position = 'relative';
    infoEl.appendChild(btn);
    card.addEventListener('mouseenter', () => btn.style.opacity = '1');
    card.addEventListener('mouseleave', () => btn.style.opacity = '0');
  }

  btn.addEventListener('click', e => {
    e.stopPropagation();
    const nameEl = card.querySelector('.dispatch-name');
    playSound(getSoundByType(nameEl ? nameEl.textContent.trim() : ''));
  });

  card.style.cursor = 'pointer';
  card.addEventListener('click', e => {
    if (e.target.closest('a') || e.target === btn) return;
    // Card click respects current toggle state
    const sound = getSoundForCard(card);
    if (sound) playSound(sound);
  });
}

// ── MutationObserver ──────────────────────────────────────────────────────────

let initialized = false;

const observer = new MutationObserver(mutations => {
  for (const mutation of mutations) {
    for (const node of mutation.addedNodes) {
      if (!(node instanceof Element)) continue;
      if (node.classList.contains('dispatch-widget')) {
        if (initialized) wireCard(node, true);
      } else {
        node.querySelectorAll('.dispatch-widget').forEach(card => {
          if (initialized) wireCard(card, true);
        });
      }
    }
  }
});

observer.observe(document.body, { childList: true, subtree: true });

function init() {
  createRefreshButton();
  createSimulateButton();
  createToggleButton();
  document.querySelectorAll('.dispatch-widget').forEach(c => wireCard(c, false));
  initialized = true;
  console.log('FirstDue Alerter: ready —', myUnitsOnly ? 'MY UNITS mode' : 'ALL UNITS mode');
}

if (document.querySelector('.dispatch-list')) {
  init();
} else {
  const initObserver = new MutationObserver(() => {
    if (document.querySelector('.dispatch-list')) {
      initObserver.disconnect();
      init();
    }
  });
  initObserver.observe(document.body, { childList: true, subtree: true });
}

// ── Tab refresh: duplicate → wait 5s → close original ────────────────────────

const REFRESH_INTERVAL_MS = 60 * 60 * 1000; // 1 hour

function doRefresh() {
  console.log('FirstDue Alerter: duplicating tab, closing this one in 5s');
  const newTab = window.open(location.href, '_blank');
  if (!newTab) {
    console.warn('FirstDue Alerter: could not open new tab — allow popups for this site');
    return;
  }
  setTimeout(() => {
    console.log('FirstDue Alerter: closing original tab');
    window.close();
  }, 5000);
}

function createRefreshButton() {
  const btn = document.createElement('button');
  btn.id = 'fd-alerter-refresh';
  btn.textContent = '🔄';
  btn.title = 'Refresh session (opens new tab, closes this one in 5s)';
  btn.style.cssText = `
    position: fixed; top: 12px; right: 248px; z-index: 99999;
    color: #fff; background: #1a7a4a; border: none; border-radius: 6px;
    padding: 7px 11px; font-size: 13px; font-weight: 600; cursor: pointer;
    box-shadow: 0 2px 8px rgba(0,0,0,0.35); letter-spacing: 0.4px;
  `;
  btn.addEventListener('click', doRefresh);
  document.body.appendChild(btn);
}

setInterval(doRefresh, REFRESH_INTERVAL_MS);